2-MINUTE BIRTHDAY COUNTDOWN — CLOUDFLARE WORKER

1. Open Cloudflare Dashboard > Workers & Pages > your Worker > Edit code.
2. Replace the Worker source with the contents of worker.js.
3. Click Deploy.
4. Confirm the Worker route covers mylove-143.in/*.
5. Visit https://mylove-143.in/ and watch the 2-minute countdown.
6. At zero, the Worker proxies the birthday website from https://inspiring-duckanoo-d9a9e9.netlify.app/ while retaining your custom domain in the browser.

NOTES:
- Timer starts when the browser first visits the Worker, and persists through refresh using a cookie.
- This is only the two-minute test version, not the final February 24, 2027 countdown.
- Some external website features or absolute URLs may still redirect to the original host.
- For a new test on the same browser, clear cookies for mylove-143.in or use a private tab.
