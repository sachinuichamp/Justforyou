const DESTINATION = 'https://inspiring-duckanoo-d9a9e9.netlify.app';
const DURATION_MS = 2 * 60 * 1000;
const COOKIE_NAME = 'mylove_test_started';

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const cookies = request.headers.get('Cookie') || '';
    const match = cookies.match(new RegExp('(?:^|;\\s*)' + COOKIE_NAME + '=(\\d+)'));
    const now = Date.now();
    let started = match ? Number(match[1]) : now;
    if (!Number.isFinite(started) || started > now || started < now - 86400000) started = now;
    const expires = started + DURATION_MS;
    if (now >= expires) {
      const upstream = new URL(url.pathname + url.search, DESTINATION);
      const headers = new Headers(request.headers);
      headers.delete('cookie');
      headers.delete('host');
      const response = await fetch(new Request(upstream, {method: request.method, headers, body: ['GET','HEAD'].includes(request.method) ? undefined : request.body, redirect: 'follow'}));
      const resultHeaders = new Headers(response.headers);
      resultHeaders.delete('content-security-policy');
      resultHeaders.delete('content-length');
      resultHeaders.delete('set-cookie');
      resultHeaders.set('cache-control', 'no-store');
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('text/html')) {
        let html = await response.text();
        // Keep absolute asset links on the custom domain where possible.
        html = html.replaceAll(DESTINATION, url.origin).replaceAll(DESTINATION + '/', url.origin + '/');
        return new Response(html, {status: response.status, headers: resultHeaders});
      }
      return new Response(response.body, {status: response.status, headers: resultHeaders});
    }
    const html = page(expires);
    return new Response(html, {headers: {'content-type':'text/html; charset=utf-8', 'cache-control':'no-store', 'set-cookie':`${COOKIE_NAME}=${started}; Path=/; Max-Age=86400; Secure; SameSite=Lax`}});
  }
};

function page(expires) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Something Thoughtful Is Coming</title><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500&family=Italiana&display=swap" rel="stylesheet"><style>
:root{--cream:#f7efe5;--gold:#d8b991}*{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:'DM Sans',sans-serif;color:var(--cream)}body{min-height:100svh;display:grid;place-items:center;padding:24px 16px;background:radial-gradient(ellipse at 15% 20%,#6d4d483d,transparent 45%),radial-gradient(ellipse at 85% 80%,#a4785633,transparent 45%),#151317;overflow:hidden}.orb{position:fixed;border-radius:50%;filter:blur(65px);pointer-events:none}.a{width:260px;height:260px;top:-70px;left:-80px;background:#b8876550}.b{width:300px;height:300px;bottom:-130px;right:-90px;background:#88654b55}.card{position:relative;width:min(100%,540px);text-align:center;padding:clamp(30px,7vw,58px) clamp(18px,5vw,42px);background:linear-gradient(140deg,#ffffff17,#ffffff07);border:1px solid #e8cfaa40;border-radius:26px;box-shadow:0 20px 90px #0008,inset 0 1px #ffffff24;backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px)}.eyebrow{font-size:10px;letter-spacing:.32em;text-transform:uppercase;color:var(--gold)}h1{font-family:Italiana,serif;font-weight:400;font-size:clamp(35px,8vw,58px);line-height:1.12;margin:22px 0}.sub{font-size:13px;line-height:1.8;color:#e9ddceae;max-width:300px;margin:0 auto 30px}.clock{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}.unit{padding:18px 4px 14px;background:#ffffff0b;border:1px solid #e8cfaa25;border-radius:14px}.num{font-family:Italiana,serif;font-size:clamp(27px,7vw,42px);font-variant-numeric:tabular-nums}.lbl{margin-top:8px;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#dfc9aeaa}.foot{font-size:11px;color:#cbb8a0a8;margin-top:29px}.line{height:1px;width:46px;margin:26px auto 0;background:#d8b99170}@media(max-width:360px){.clock{gap:5px}.unit{padding:15px 2px}.lbl{font-size:8px}}
</style></head><body><div class="orb a"></div><div class="orb b"></div><main class="card"><div class="eyebrow">A little surprise awaits</div><h1>Something thoughtful<br>is coming.</h1><p class="sub">A little time, a little care.<br>See you here soon.</p><div class="clock"><div class="unit"><div class="num" id="d">00</div><div class="lbl">Days</div></div><div class="unit"><div class="num" id="h">00</div><div class="lbl">Hours</div></div><div class="unit"><div class="num" id="m">02</div><div class="lbl">Minutes</div></div><div class="unit"><div class="num" id="s">00</div><div class="lbl">Seconds</div></div></div><div class="line"></div><div class="foot" id="foot">2-minute preview</div></main><script>
const end=${expires};const pad=n=>String(n).padStart(2,'0');function tick(){const left=Math.max(0,Math.ceil((end-Date.now())/1000));document.getElementById('d').textContent=pad(Math.floor(left/86400));document.getElementById('h').textContent=pad(Math.floor(left%86400/3600));document.getElementById('m').textContent=pad(Math.floor(left%3600/60));document.getElementById('s').textContent=pad(left%60);if(left===0){document.getElementById('foot').textContent='Opening your surprise…';location.replace(location.href);return}}tick();setInterval(tick,500);
</script></body></html>`;
}
